
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function FitMindBody50() {
  const [email, setEmail] = useState("");
  const [leadDownloaded, setLeadDownloaded] = useState(false);
  const [post, setPost] = useState("");
  const [posts, setPosts] = useState([]);

  const handleDownload = () => {
    if (email.includes("@")) {
      setLeadDownloaded(true);
    }
  };

  const handlePostSubmit = () => {
    if (post.trim() !== "") {
      setPosts([{ content: post, date: new Date().toLocaleString() }, ...posts]);
      setPost("");
    }
  };

  return (
    <div className="p-6 grid gap-6 max-w-4xl mx-auto">
      <motion.h1 
        className="text-3xl font-bold text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        FitMindBody50 Portal
      </motion.h1>

      <Card>
        <CardContent className="grid gap-4 p-4">
          <h2 className="text-xl font-semibold">Download Your Spartan RESET Checklist</h2>
          <Input
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button onClick={handleDownload} disabled={leadDownloaded}>
            {leadDownloaded ? "Checklist Downloaded" : "Download Now"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-4 p-4">
          <h2 className="text-xl font-semibold">Daily Spartan Post Scheduler</h2>
          <Textarea
            placeholder="Write your daily FitMindBody50 post..."
            value={post}
            onChange={(e) => setPost(e.target.value)}
          />
          <Button onClick={handlePostSubmit}>Post</Button>
        </CardContent>
      </Card>

      {posts.length > 0 && (
        <div className="grid gap-4">
          <h3 className="text-lg font-medium">Scheduled Posts</h3>
          {posts.map((p, idx) => (
            <Card key={idx}>
              <CardContent className="p-4">
                <p className="text-sm text-gray-600">{p.date}</p>
                <p className="text-base mt-2">{p.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
